# Kasa Sistemi - Skin Resource Pack (Minecraft 1.21.11 uyumlu)

Bu paket, Minecraft'ın 1.21.4 ile getirdiği **yeni eşya modeli sistemine**
göre hazırlanmıştır (`assets/minecraft/items/*.json` + `range_dispatch`).
Eski `custom_model_data` + `overrides` yöntemi 1.21.4 sonrasında
kullanılmadığı için pack bu yeni formata göre yazıldı.

14 eşyaya (kılıç, balta, kazma, kürek, çapa, olta, zırhlar) gerçek 3D model
(cuboid/element tabanlı) uygulanmıştır. **Kalkanlar hariç tutulmuştur** —
Minecraft'ta kalkanlar elde tutulurken özel bir render sistemi (banner
benzeri doku formatı) kullanıyor ve standart eşya modeliyle override
edilince bozuk görünüyor. Kalkanlar (Çelik Kalkan, Karanlık Kalkan) isim ve
nadirlik rengiyle ayırt edilmeye devam ediyor, görseli varsayılan kalkan.

## Önemli: Sürüm Uyumluluğu

`pack_format: 75` → sadece **Minecraft 1.21.9 - 1.21.11** ile uyumludur.
Sunucunuzun sürümü değişirse (örn. 1.21.1'e düşer veya 1.22'ye çıkarsa) bu
sayıyı güncellemeniz gerekir — aksi halde pack "eski/uyumsuz" uyarısı verir.

## 1. Sunucuya Uygulama

**SaganNetwork panelinde genelde iki yöntem olur:**

**A) Panel üzerinden yükleme (varsa)**
- Panelde "Resource Pack" / "Doku Paketi" sekmesini bulun
- Bu zip dosyasını doğrudan yükleyin

**B) URL ile (server.properties)**
- Bu zip'i bir dosya barındırma servisine yükleyin (örn. kendi web siteniz,
  Dropbox direct-link, GitHub Releases) ve linkini alın
- `server.properties` dosyasında:
  ```
  resource-pack=https://.../kasasistemi_resourcepack.zip
  resource-pack-sha1=<zip dosyasının SHA1 hash'i>
  require-resource-pack=false
  ```
- SHA1 hash'i almak için: `sha1sum kasasistemi_resourcepack.zip` (Linux/Mac)
  veya PowerShell'de `Get-FileHash -Algorithm SHA1 dosya.zip`

## 2. Kendi Tasarımlarınızı Eklemek / Değiştirmek

Her skin üç dosyadan oluşur, ID'yi (ör. `4001`) hepsinde eşleştirin:

- `assets/minecraft/textures/item/custom/4001_primary.png` → ana renk/doku (16x16)
- `assets/minecraft/textures/item/custom/4001_secondary.png` → sap/kenar rengi (16x16)
- `assets/minecraft/models/item/custom/4001.json` → 3D gövde (elements) + hangi
  dokuların hangi yüzeye uygulandığı

Renkleri değiştirmek için sadece PNG dosyalarını düzenlemeniz yeterli — 3D
şekli değiştirmek isterseniz `.json` içindeki `elements` listesindeki
`from`/`to` koordinatlarını (0-16 arası, Minecraft model birimi) düzenleyin.

Yeni bir eşyaya skin eklemek isterseniz (yeni bir `model-data` ID'si),
`assets/minecraft/items/<taban_esya>.json` dosyasındaki `entries` listesine
yeni bir `{"threshold": YENİ_ID, "model": {...}}` girişi eklemeniz gerekir —
sadece doku/model dosyası eklemek yeterli değildir, aksi halde oyun o ID'yi
tanımaz.

## 3. Yeni Skin Eklerken Dikkat

`crates.yml`'e yeni bir ödül eklediğinizde (`model-data: XXXX`), bu resource
pack'e de karşılığını eklemeniz gerekir, yoksa oyuncular varsayılan (düz)
eşya görünümünü görür:

1. `assets/minecraft/textures/item/custom/XXXX.png` dokusunu ekleyin
2. `assets/minecraft/models/item/custom/XXXX.json` dosyasını ekleyin (var olan
   bir tanesini kopyalayıp `layer0` satırındaki ID'yi değiştirin)
3. İlgili taban eşyanın override dosyasına (`models/item/diamond_sword.json`
   gibi) yeni bir `predicate/custom_model_data` girişi ekleyin

## 4. Not: Zırh ve Kalkan Sınırlaması

Bu paketteki zırh parçaları (miğfer, göğüslük vb.) sadece **envanterdeki
ikonu** değiştirir; oyuncu üzerine giydiğinde 3D zırh modelinin dokusu
değişmeyebilir (Minecraft 1.20+ "armor trim" sistemi ayrı bir konu ve daha
gelişmiş bir kurulum gerektirir). Kalkan da benzer bir sınırlamaya sahiptir.
Kılıç, kazma, balta, kürek, çapa ve olta için skin değişimi elde/yerde tam
görünür.
