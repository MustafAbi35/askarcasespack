# Özel GUI Paketi — Koyu + Altın Tema

## Ne Yapıyor?

`gui/container/generic_54.png` dosyasını değiştiriyor — bu, Minecraft'ın
**TÜM** sandık-tipi menülerde (gerçek sandıklar, ender sandık, shulker box,
VE tüm plugin GUI'leri — AskarCases'teki kasa önizlemesi, kasa listesi,
anahtar listesi dahil) kullandığı **tek** arka plan dosyası. Bu yüzden bunu
değiştirince otomatik olarak her yerde uygulanır, ayrıca hiçbir Java kodu
değişikliği gerekmez.

## Kurulum

1. Bu zip'i GitHub'a (ya da başka bir barındırma) yükleyin
2. `server.properties`'teki `resource-pack` ve `resource-pack-sha1` satırlarını
   güncelleyin (SHA1'i aşağıda hesapladım)
3. Sunucuyu restart edin

**Önceden bir resource pack kullanıyorsanız:** İkisini BİRLEŞTİRMENİZ gerekir
— aynı anda sadece bir resource pack aktif olabilir. Bu klasördeki
`assets/minecraft/textures/gui/container/generic_54.png` dosyasını, mevcut
resource pack'inizin AYNI klasör yoluna kopyalayıp tek bir zip halinde
yeniden paketleyin.

## Önemli — Test Etmeniz Gerekiyor

Bu dosya, Minecraft'ın bilinen standart piksel şablonuna (176x222,
6 satır x 9 sütun slot ızgarası + oyuncu envanteri + hotbar) göre
hazırlandı — ama gerçek oyunda **görüp onaylamanız** önemli, çünkü bu tür
piksel-hassas dosyalarda küçük bir kayma bile garip görünmeye yol açabilir.

Test etmek için:
1. Zip'i `.minecraft/resourcepacks/` klasörünüze atın (kendi bilgisayarınızda)
2. Tek oyunculu bir dünyada etkinleştirin
3. Bir sandık açın, ya da `/kasaliste` gibi bir plugin menüsü açın
4. Sorun görürseniz (slotlar kaymış, çizgiler yanlış yerde) bana söyleyin,
   düzeltelim

## Özelleştirme

Renkleri beğenmezseniz `assets/minecraft/textures/gui/container/generic_54.png`
dosyasını herhangi bir görsel editörle (Photoshop, GIMP, Paint.NET) açıp
üzerine boyayabilirsiniz — SADECE dosyanın **176x222 piksel** olan sol-üst
bölgesindeki içeriği değiştirin, geri kalan (256x256'ya tamamlayan boş alan)
kullanılmıyor, dokunmanıza gerek yok.
